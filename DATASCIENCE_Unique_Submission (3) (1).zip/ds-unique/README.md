# DATASCIENCE · Digital Library

Unique dark academic theme · Project submission build  
**Ravella Sushmitha** · Mohan Babu University · B.Tech Data Science

## Features kept
- Student ID card + photo upload
- 5 course modules with full notes
- Lab experiments with live Python (Pyodide)
- Cached outputs for selected experiments
- Tools & About / Resume

## How to open
Use **Live Server** or:
```bash
python -m http.server 8000
```
Open `http://localhost:8000` (not `file://`).

## GitHub Pages
Upload `index.html` → Settings → Pages → Deploy from `main` / root.
