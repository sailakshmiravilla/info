# Data Science Digital Library – Backend (Python / Flask)

## Run locally
```bash
cd backend
python3 -m venv venv && source venv/bin/activate
pip install -r requirements.txt
export ADMIN_KEY="some-long-secret"      # optional, enables admin routes
python app.py                            # http://localhost:5000
```
The SQLite DB (`library.db`) is created and seeded from `data/seed.json` on first start.

## API
| Method | Route | Notes |
|---|---|---|
| GET | /api/health | |
| GET/PUT | /api/student | PUT needs `X-Admin-Key` |
| GET | /api/modules, /api/modules/<id> | |
| GET/POST | /api/experiments | POST needs `X-Admin-Key` |
| GET/PUT/DELETE | /api/experiments/<id> | PUT/DELETE need `X-Admin-Key` |
| GET | /api/tools | |
| GET | /api/resume | serves `static/resume.pdf` |
| POST | /api/run | `{"code": "..."}` -> `{status, stdout, stderr, exit_code, duration_ms}` |

Quick test:
```bash
curl localhost:5000/api/experiments/1
curl -X POST localhost:5000/api/run -H 'Content-Type: application/json' -d '{"code":"print(2+2)"}'
```

## Connect the frontend
See `frontend_snippet.js`. Set `ALLOWED_ORIGIN` to your GitHub Pages URL in production.

## Deploy
Render / Railway / any host: start command `gunicorn app:app`. (`Procfile` included.)
Edit your name/college/email via `PUT /api/student`, or edit `data/seed.json` before first run.

## Security note on /api/run
The runner uses an isolated subprocess with CPU/memory/file/process limits, a 5 s timeout,
output caps and per-IP rate limiting. It does NOT block network access or reading files the
server user can read. For a public site, run the backend in a Docker container with
`--network none --read-only --memory 256m` (or use a service like Judge0/Piston).
