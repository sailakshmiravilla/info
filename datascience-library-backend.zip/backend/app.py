"""
Data Science Digital Library - Backend (Flask + SQLite)

Endpoints
  GET    /api/health
  GET    /api/student
  PUT    /api/student                 (admin)
  GET    /api/modules
  GET    /api/modules/<id>
  GET    /api/experiments
  GET    /api/experiments/<id>
  POST   /api/experiments             (admin)
  PUT    /api/experiments/<id>        (admin)
  DELETE /api/experiments/<id>        (admin)
  GET    /api/tools
  GET    /api/resume                  (serves static/resume.pdf)
  POST   /api/run                     {"code": "print('hi')"} -> real Python execution
"""
import json
import os
import resource
import sqlite3
import signal
import subprocess
import sys
import tempfile
import time
from collections import defaultdict, deque
from pathlib import Path

from flask import Flask, g, jsonify, request, send_from_directory

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = os.environ.get("DB_PATH", str(BASE_DIR / "library.db"))
SEED_PATH = BASE_DIR / "data" / "seed.json"
ADMIN_KEY = os.environ.get("ADMIN_KEY", "")            # set this to enable admin routes
ALLOWED_ORIGIN = os.environ.get("ALLOWED_ORIGIN", "*")  # e.g. https://<user>.github.io

# Code-runner limits
RUN_TIMEOUT_SEC = 5
RUN_MEM_BYTES = 256 * 1024 * 1024
RUN_MAX_CODE_CHARS = 20_000
RUN_MAX_OUTPUT_CHARS = 10_000
RUN_RATE_LIMIT = 15          # requests
RUN_RATE_WINDOW_SEC = 60     # per window, per IP

app = Flask(__name__)


# ----------------------------------------------------------------- database
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


SCHEMA = """
CREATE TABLE IF NOT EXISTS student (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    name TEXT, role TEXT, reg TEXT, dept TEXT, college TEXT, email TEXT, focus TEXT
);
CREATE TABLE IF NOT EXISTS modules (
    id INTEGER PRIMARY KEY, title TEXT NOT NULL, topics TEXT NOT NULL, color TEXT
);
CREATE TABLE IF NOT EXISTS experiments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL, description TEXT, steps TEXT NOT NULL, code TEXT
);
CREATE TABLE IF NOT EXISTS tools (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL, desc TEXT, icon TEXT, color TEXT
);
"""


def init_db():
    db = sqlite3.connect(DB_PATH)
    db.executescript(SCHEMA)
    if db.execute("SELECT COUNT(*) FROM modules").fetchone()[0] == 0 and SEED_PATH.exists():
        seed = json.loads(SEED_PATH.read_text(encoding="utf-8"))
        s = seed["studentInfo"]
        db.execute(
            "INSERT OR REPLACE INTO student VALUES (1,?,?,?,?,?,?,?)",
            (s["name"], s["role"], s["reg"], s["dept"], s["college"], s["email"], s["focus"]),
        )
        for m in seed["modules"]:
            db.execute("INSERT INTO modules VALUES (?,?,?,?)",
                       (m["id"], m["title"], json.dumps(m["topics"]), m.get("color")))
        for e in seed["experiments"]:
            db.execute("INSERT INTO experiments (id,title,description,steps,code) VALUES (?,?,?,?,?)",
                       (e["id"], e["title"], e.get("description"), json.dumps(e["steps"]), e.get("code")))
        for t in seed["tools"]:
            db.execute("INSERT INTO tools (name,desc,icon,color) VALUES (?,?,?,?)",
                       (t["name"], t["desc"], t.get("icon"), t.get("color")))
    db.commit()
    db.close()


def module_dict(r):
    return {"id": r["id"], "title": r["title"], "topics": json.loads(r["topics"]), "color": r["color"]}


def experiment_dict(r):
    return {"id": r["id"], "title": r["title"], "description": r["description"],
            "steps": json.loads(r["steps"]), "code": r["code"]}


# ------------------------------------------------------------- CORS / auth
@app.after_request
def add_cors(resp):
    resp.headers["Access-Control-Allow-Origin"] = ALLOWED_ORIGIN
    resp.headers["Access-Control-Allow-Headers"] = "Content-Type, X-Admin-Key"
    resp.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, DELETE, OPTIONS"
    return resp


@app.route("/api/<path:_any>", methods=["OPTIONS"])
def preflight(_any):
    return ("", 204)


def admin_required():
    """Return an error response if the request lacks a valid admin key, else None."""
    import hmac
    if not ADMIN_KEY:
        return jsonify(error="Admin routes disabled (ADMIN_KEY not set)"), 403
    if not hmac.compare_digest(request.headers.get("X-Admin-Key", ""), ADMIN_KEY):
        return jsonify(error="Invalid admin key"), 401
    return None


# --------------------------------------------------------------- read routes
@app.get("/api/health")
def health():
    return jsonify(status="ok")


@app.get("/api/student")
def get_student():
    r = get_db().execute("SELECT * FROM student WHERE id = 1").fetchone()
    return jsonify({k: r[k] for k in r.keys() if k != "id"} if r else {})


@app.put("/api/student")
def update_student():
    if (err := admin_required()):
        return err
    data = request.get_json(silent=True) or {}
    fields = ["name", "role", "reg", "dept", "college", "email", "focus"]
    cols = [f for f in fields if f in data]
    if not cols:
        return jsonify(error="No valid fields"), 400
    db = get_db()
    db.execute("INSERT OR IGNORE INTO student (id) VALUES (1)")
    db.execute(f"UPDATE student SET {', '.join(c + '=?' for c in cols)} WHERE id = 1",
               [str(data[c]) for c in cols])
    db.commit()
    return get_student()


@app.get("/api/modules")
def list_modules():
    rows = get_db().execute("SELECT * FROM modules ORDER BY id").fetchall()
    return jsonify([module_dict(r) for r in rows])


@app.get("/api/modules/<int:mid>")
def get_module(mid):
    r = get_db().execute("SELECT * FROM modules WHERE id = ?", (mid,)).fetchone()
    return (jsonify(module_dict(r)) if r else (jsonify(error="Not found"), 404))


@app.get("/api/experiments")
def list_experiments():
    rows = get_db().execute("SELECT * FROM experiments ORDER BY id").fetchall()
    return jsonify([experiment_dict(r) for r in rows])


@app.get("/api/experiments/<int:eid>")
def get_experiment(eid):
    r = get_db().execute("SELECT * FROM experiments WHERE id = ?", (eid,)).fetchone()
    return (jsonify(experiment_dict(r)) if r else (jsonify(error="Not found"), 404))


@app.get("/api/tools")
def list_tools():
    rows = get_db().execute("SELECT name, desc, icon, color FROM tools ORDER BY id").fetchall()
    return jsonify([dict(r) for r in rows])


@app.get("/api/resume")
def resume():
    path = BASE_DIR / "static" / "resume.pdf"
    if not path.exists():
        return jsonify(error="Place your resume at backend/static/resume.pdf"), 404
    return send_from_directory(path.parent, path.name, mimetype="application/pdf")


# -------------------------------------------------------- admin write routes
def _validate_experiment(data):
    if not isinstance(data.get("title"), str) or not data["title"].strip():
        return "title is required"
    if not isinstance(data.get("steps"), list) or not all(isinstance(s, str) for s in data["steps"]):
        return "steps must be a list of strings"
    return None


@app.post("/api/experiments")
def create_experiment():
    if (err := admin_required()):
        return err
    data = request.get_json(silent=True) or {}
    if (msg := _validate_experiment(data)):
        return jsonify(error=msg), 400
    db = get_db()
    cur = db.execute("INSERT INTO experiments (title,description,steps,code) VALUES (?,?,?,?)",
                     (data["title"], data.get("description"), json.dumps(data["steps"]), data.get("code")))
    db.commit()
    return get_experiment(cur.lastrowid).get_json(), 201


@app.put("/api/experiments/<int:eid>")
def update_experiment(eid):
    if (err := admin_required()):
        return err
    data = request.get_json(silent=True) or {}
    if (msg := _validate_experiment(data)):
        return jsonify(error=msg), 400
    db = get_db()
    cur = db.execute("UPDATE experiments SET title=?, description=?, steps=?, code=? WHERE id=?",
                     (data["title"], data.get("description"), json.dumps(data["steps"]),
                      data.get("code"), eid))
    db.commit()
    return (get_experiment(eid) if cur.rowcount else (jsonify(error="Not found"), 404))


@app.delete("/api/experiments/<int:eid>")
def delete_experiment(eid):
    if (err := admin_required()):
        return err
    db = get_db()
    cur = db.execute("DELETE FROM experiments WHERE id = ?", (eid,))
    db.commit()
    return ("", 204) if cur.rowcount else (jsonify(error="Not found"), 404)


# ------------------------------------------------------------ code runner
_hits = defaultdict(deque)


def rate_limited(ip):
    now = time.time()
    q = _hits[ip]
    while q and now - q[0] > RUN_RATE_WINDOW_SEC:
        q.popleft()
    if len(q) >= RUN_RATE_LIMIT:
        return True
    q.append(now)
    return False


def _limit_resources():
    """Runs in the child process just before exec (POSIX only)."""
    resource.setrlimit(resource.RLIMIT_CPU, (RUN_TIMEOUT_SEC, RUN_TIMEOUT_SEC))
    resource.setrlimit(resource.RLIMIT_AS, (RUN_MEM_BYTES, RUN_MEM_BYTES))
    resource.setrlimit(resource.RLIMIT_FSIZE, (1024 * 1024, 1024 * 1024))
    resource.setrlimit(resource.RLIMIT_NPROC, (64, 64))
    os.setsid()


@app.post("/api/run")
def run_code():
    data = request.get_json(silent=True) or {}
    code = data.get("code")
    if not isinstance(code, str) or not code.strip():
        return jsonify(error="'code' (string) is required"), 400
    if len(code) > RUN_MAX_CODE_CHARS:
        return jsonify(error=f"Code too long (max {RUN_MAX_CODE_CHARS} chars)"), 413
    if rate_limited(request.remote_addr or "?"):
        return jsonify(error="Too many runs, slow down"), 429

    started = time.time()
    with tempfile.TemporaryDirectory() as tmp:
        script = Path(tmp) / "main.py"
        script.write_text(code, encoding="utf-8")
        try:
            # -I isolated mode, -B no .pyc; minimal environment
            proc = subprocess.run(
                [sys.executable, "-I", "-B", str(script)],
                cwd=tmp, capture_output=True, text=True, timeout=RUN_TIMEOUT_SEC + 2,
                env={"PATH": "/usr/bin:/bin", "MPLBACKEND": "Agg", "HOME": tmp},
                preexec_fn=_limit_resources, stdin=subprocess.DEVNULL,
            )
            out, err, status, rc = proc.stdout, proc.stderr, \
                ("success" if proc.returncode == 0 else "error"), proc.returncode
            if proc.returncode in (-signal.SIGXCPU, -signal.SIGKILL):
                status, err = "timeout", err or f"Time/CPU limit exceeded ({RUN_TIMEOUT_SEC}s)"
        except subprocess.TimeoutExpired:
            out, err, status, rc = "", f"Time limit exceeded ({RUN_TIMEOUT_SEC}s)", "timeout", -1

    cut = lambda s: s if len(s) <= RUN_MAX_OUTPUT_CHARS else s[:RUN_MAX_OUTPUT_CHARS] + "\n...[output truncated]"
    return jsonify(status=status, stdout=cut(out), stderr=cut(err), exit_code=rc,
                   duration_ms=int((time.time() - started) * 1000))


# --------------------------------------------------------------------- main
init_db()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)
