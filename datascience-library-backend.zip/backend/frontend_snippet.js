// Paste into index.html's <script> and set API to your deployed backend URL.
const API = "http://localhost:5000";

// Replace the simulated runCompiler() with this real one:
async function runCompiler() {
  const code = document.getElementById('code-editor').value;
  const outputEl = document.getElementById('code-output');
  const statusEl = document.getElementById('compiler-status');
  statusEl.textContent = 'Running...';
  try {
    const res = await fetch(`${API}/api/run`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code })
    });
    const d = await res.json();
    if (!res.ok) throw new Error(d.error || res.statusText);
    outputEl.textContent = (d.stdout || '') + (d.stderr ? '\n' + d.stderr : '') +
                           `\n[${d.status} • ${d.duration_ms} ms]`;
    statusEl.textContent = d.status === 'success' ? 'Success' : 'Error';
  } catch (e) {
    outputEl.textContent = 'Error: ' + e.message;
    statusEl.textContent = 'Error';
  }
}

// Load content from the backend instead of hard-coded arrays:
async function loadContent() {
  const [s, m, e, t] = await Promise.all(
    ['student', 'modules', 'experiments', 'tools'].map(p => fetch(`${API}/api/${p}`).then(r => r.json()))
  );
  Object.assign(studentInfo, s);
  modules.splice(0, modules.length, ...m);
  experiments.splice(0, experiments.length, ...e);
  tools.splice(0, tools.length, ...t);
}
// then in DOMContentLoaded: await loadContent() before the render*() calls.

function downloadResume() { window.open(`${API}/api/resume`, '_blank'); }
